-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 06, 2018 at 08:30 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `musicbuydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customertbl`
--

DROP TABLE IF EXISTS `customertbl`;
CREATE TABLE IF NOT EXISTS `customertbl` (
  `cust_id` int(5) NOT NULL AUTO_INCREMENT,
  `cust_fname` varchar(20) NOT NULL,
  `cust_lname` varchar(20) NOT NULL,
  `cust_email` varchar(20) NOT NULL,
  `cust_passw` varchar(7) NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customertbl`
--

INSERT INTO `customertbl` (`cust_id`, `cust_fname`, `cust_lname`, `cust_email`, `cust_passw`) VALUES
(1, 'Kate', 'Austin', 'kaustin@lost.com', 'a123456'),
(2, 'Jack', 'Shepherd', 'jshepherd@lost.com', 'jwed312'),
(3, 'Saheed', 'Sahid', 'sas@lost.com', 's222222'),
(4, 'asdad', 'Sahid', 's@d.com', 's23123e'),
(5, 's', 'Sahid', 's@s.com', 's222ee'),
(6, 'James', 'Bond', 'jb@bond.com', 'g123456'),
(7, 'James', 'Bond', 'jb@bond.com', 'j123456'),
(8, 'Mick', 'Smith', 'msmith@fake.com', 's12345a'),
(9, 'Simon', 'Templar', 'saint@tv.com', 'saint12'),
(10, 'Hand', 'feet', '123@qq.com', 'hhhh234'),
(11, 'Jamess', 'Bond', 'jb@bond.com', 'j12f456'),
(12, 'Jamess', 'sahid', 's@d.com', 's231x3e'),
(13, 'Jamess', 'sahid', 's@d.com', 's231w3e'),
(14, 'Bobby', 'Chan', 'bc@stunning.com', 'f839104'),
(15, 'testF', 'testL', '123456789@test.com', 'j12345x'),
(16, 'xyz', 'abc', 'sdjaio@fmd.com', 't789654'),
(17, 'QQQ', 'UUU', 'QQUU@GMAIL.COM', 't789654'),
(18, 'QQQ', 'AAA', 'QQUU@GMAIL.COM', 't789654');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
